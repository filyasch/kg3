import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ObjReader {

    public void readFile(String filePath) throws InvalidFileFormatException, IOException {
        // Ваш код для чтения файла
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            // Чтение файла
            // Если формат не соответствует ожидаемому, выбрасываем исключение
            if (!isValidFormat()) {
                throw new InvalidFileFormatException("Invalid file format");
            }
        }
    }

    private boolean isValidFormat() {
        // Ваша логика проверки формата файла
        // Возвращает true, если формат верный, иначе false
        return true;
    }
}
