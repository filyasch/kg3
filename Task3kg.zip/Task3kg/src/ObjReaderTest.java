import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.fail;

public class ObjReaderTest {


    @Test
    public void testMissingVertices() {
        ObjReader objReader = new ObjReader();
        try {
            objReader.readFile("missingVertices.obj");
            fail("Expected IOException or InvalidFileFormatException");
        } catch (IOException | InvalidFileFormatException e) {
            // Ожидаемое исключение IOException или InvalidFileFormatException
        }
    }

    @Test
    public void testInsufficientPolygons() {
        ObjReader objReader = new ObjReader();
        try {
            objReader.readFile("insufficientPolygons.obj");
            fail("Expected IOException or InvalidFileFormatException");
        } catch (IOException | InvalidFileFormatException e) {
            // Ожидаемое исключение IOException или InvalidFileFormatException
        }
    }

    // Дополнительные тесты...
}
